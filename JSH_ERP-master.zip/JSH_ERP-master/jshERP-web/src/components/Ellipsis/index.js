import Ellipsis from './Ellipsis'

export default Ellipsis